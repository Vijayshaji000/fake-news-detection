# Fake News Detection Using NLP and ML

Run train_model.py then app.py using Streamlit.